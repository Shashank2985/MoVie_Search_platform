const MovieCard = ({ movie }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <img
        src={
          movie.i?.imageUrl ||
          "https://via.placeholder.com/500x750?text=No+Image"
        }
        alt={movie.l}
        className="w-full h-60 object-cover"
      />
      <div className="p-2">
        <h2 className="font-semibold text-md truncate">{movie.l}</h2>
        <p className="text-sm text-gray-600 truncate">{movie.s}</p>
        <p className="text-sm text-gray-500">{movie.y}</p>
      </div>
    </div>
  );
};

export default MovieCard;
