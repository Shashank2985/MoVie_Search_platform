import { NavLink } from "react-router-dom";
import { Home, Tv, Film, User } from "lucide-react";

const BottomNav = () => {
  return (
    <div className="fixed bottom-0 w-full bg-white border-t flex justify-around items-center py-2 lg:hidden">
      <NavLink to="/" className="flex flex-col items-center">
        <Home size={24} />
        <span className="text-xs">Movies</span>
      </NavLink>
      <NavLink to="/tvshows" className="flex flex-col items-center">
        <Tv size={24} />
        <span className="text-xs">TV</span>
      </NavLink>
      <NavLink to="/webseries" className="flex flex-col items-center">
        <Film size={24} />
        <span className="text-xs">Web</span>
      </NavLink>
      <NavLink to="/myspace" className="flex flex-col items-center">
        <User size={24} />
        <span className="text-xs">MySpace</span>
      </NavLink>
    </div>
  );
};

export default BottomNav;
