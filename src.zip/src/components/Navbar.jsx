import SearchBar from "./Searchbar";

const Navbar = () => {
  return (
    <div className="w-full p-4 flex justify-between items-center border-b bg-black fixed top-0 z-50 lg:justify-start lg:gap-10">
      <div className="text-2xl font-bold text-white">🎬 Flixify</div>
      <div className="w-full max-w-md">
        <SearchBar />
      </div>
      <div className="hidden lg:flex items-center gap-6 text-sm font-medium ml-auto py-2 px-4">
        <a className="bg-amber-400 px-4 py-2 rounded-lg text-center" href="/">
          Movies
        </a>
        <a
          className="bg-amber-400 px-4 py-2 rounded-lg text-center"
          href="/tvshows"
        >
          TV Shows
        </a>
        <a
          className="bg-amber-400 px-4 py-2 rounded-lg text-center"
          href="/webseries"
        >
          Web Series
        </a>
        <a
          className="bg-amber-400 px-4 py-2 rounded-lg text-center"
          href="/myspace"
        >
          MySpace
        </a>
      </div>
    </div>
  );
};

export default Navbar;
