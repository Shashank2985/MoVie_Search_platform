import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import BottomNav from "./components/BottomNav";
import Movies from "./pages/Movies";
import RapidAPIFetch from "./components/RapidAPIFetch";
// import other pages when ready

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 p-4">
        <Routes>
          <Route path="/" element={<Movies />} />
          {/* <Route path="/tvshows" element={<TVShows />} />
          <Route path="/webseries" element={<WebSeries />} />
          <Route path="/myspace" element={<MySpace />} /> */}
        </Routes>
      </div>
      <BottomNav />
      <RapidAPIFetch />
    </div>
  );
}

export default App;
