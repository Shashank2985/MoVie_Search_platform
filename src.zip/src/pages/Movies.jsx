import { useEffect, useState } from "react";
import MovieCard from "../components/MovieCard";
import SearchBar from "../components/Searchbar";

const Movies = () => {
  const [movies, setMovies] = useState([]);
  const [searchTerm, setSearchTerm] = useState("avengers"); // Default term
  const [isLoading, setIsLoading] = useState(false);

  const fetchMovies = async () => {
    try {
      setIsLoading(true);
      const url = `https://imdb8.p.rapidapi.com/auto-complete?q=${searchTerm}`;
      const res = await fetch(url, {
        method: "GET",
        headers: {
          "X-RapidAPI-Key": import.meta.env.VITE_RAPIDAPI_KEY,
          "X-RapidAPI-Host": import.meta.env.VITE_RAPIDAPI_HOST,
        },
      });

      const data = await res.json();
      setMovies(data.d || []);
    } catch (error) {
      console.error("Error fetching from RapidAPI:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMovies();
  }, [searchTerm]);

  return (
    <>
      <div className="lg:hidden mt-20 mb-4 px-4">
        <SearchBar onSearch={setSearchTerm} />
      </div>

      {isLoading ? (
        <h4 className="text-center mt-10">Loading...</h4>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 px-4">
          {movies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      )}
    </>
  );
};

export default Movies;
